﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
	public class Employee // Duane Hellums, Code Louisville SWDEV1 Assignment 2, May 25 2022, 1:30 PM
	{
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string FullName
		{
			get { return string.Format("{0} {1}", FirstName, LastName); }
		}
		public DateTime StartDate { get; set; }
		public string Title { get; set; }
		public int Salary { get; set; }

		public Employee(string firstName, string lastName, DateTime startDate, string title, int salary)
		{
			FirstName = firstName;
			LastName = lastName;
			StartDate = startDate;
			Title = title;
			Salary = salary;
		}

		public void Name()
		{
			Console.WriteLine("My name is " + FullName);
		}

		public void Working(string tasking)
		{
			Console.WriteLine("I am working on " + tasking);
		}

		public void ShowTitle()
		{
			Console.WriteLine("My title is {0}", Title);
		}

		public void ShowSalary()
		{
			Console.WriteLine("I have been working here since {0} and make ${1}", StartDate.ToString("MM/dd/yyyy"), Salary);
		}
	}
}
