﻿using ConsoleApp1.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.BuilderObjects
{
    public class HouseBuilder: IBuildingBuilder
    {
        private House _house;

        public HouseBuilder()
        {
            Reset();
        }

        public void AddDoors(int numberofDoors)
        {
            _house.NumberOfDoors = numberofDoors;
        }

        public void AddFloors(int numberOfFloors)
        {
            _house.NumberOfFloors = numberOfFloors;
        }

        public void AddSecuritySystem(ISecuritySystem securitySystem)
        {
            _house.SecuritySystem = securitySystem;
        }

        public void AddWalls(int numberOfWalls)
        {
            _house.NumberOfWalls = numberOfWalls;
        }

        public void AddWindows(int numberofWindows)
        {
            _house.NumberOfWindows = numberofWindows;
        }

        public void AddYard(Yard yard)
        {
            _house.Yard = yard;
        }

        public void CurrentOccupants(List<Person> personList)
        {
            _house.PeopleInHouse = personList;
        }

        public void CurrentSquareFootage(int squareFootage)
        {
            _house.SquareFootage = squareFootage;
        }

        public void WithBasement(bool doesHaveBasement)
        {
            _house.DoesHaveBasement = doesHaveBasement;
        }

        public void WithGarage(bool doesHaveGarage)
        {
            _house.DoesHaveGarage = doesHaveGarage;
        }

        public void SetAddress(Address address)
        {
            _house.Address = address;
        }

        public IBuilding GetBuilding()
        {
            var result = _house;

            Reset();

            return result;
        }

        private void Reset()
        {
            _house = new House();
        }
    }
}
