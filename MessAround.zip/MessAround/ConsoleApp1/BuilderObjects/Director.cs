﻿using ConsoleApp1.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.BuilderObjects
{
    public class Director
    {
        private IBuildingBuilder _buildingBuilder;

        public Director(IBuildingBuilder buildingBuilder)
        {
            _buildingBuilder = buildingBuilder;
        }

        public IBuilding BuildMinimnalBuilding(int walls)
        {
            _buildingBuilder.AddWalls(walls);

            return _buildingBuilder.GetBuilding();
        }

        public IBuilding BuildFullBuilding(int numberOfWalls, int numberOfDoors, int numberOfWindows, Address address, Yard yard, ISecuritySystem securitySystem, bool doesHaveGarage, bool doesHaveBasement, List<Person> personList,
                        int numberOfFloors, int squareFootage)
        {
            _buildingBuilder.AddDoors(numberOfDoors);
            _buildingBuilder.AddWindows(numberOfWindows);
            _buildingBuilder.AddWalls(numberOfWalls);
            _buildingBuilder.SetAddress(address);
            _buildingBuilder.AddYard(yard);
            _buildingBuilder.AddSecuritySystem(securitySystem);
            _buildingBuilder.WithGarage(doesHaveGarage);
            _buildingBuilder.WithBasement(doesHaveBasement);
            _buildingBuilder.CurrentOccupants(personList);
            _buildingBuilder.AddFloors(numberOfFloors);
            _buildingBuilder.CurrentSquareFootage(squareFootage);

            return _buildingBuilder.GetBuilding();
        }
    }
}
