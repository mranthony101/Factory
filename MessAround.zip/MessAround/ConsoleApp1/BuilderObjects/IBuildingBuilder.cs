﻿using ConsoleApp1.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.BuilderObjects
{
    public interface IBuildingBuilder
    {
        #region Methods
        void AddWalls(int numberOfWalls);
        void AddDoors(int numberofDoors);
        void AddWindows(int numberofWindows);
        void AddYard(Yard yard);
        void SetAddress(Address address);
        void AddSecuritySystem(ISecuritySystem securitySystem);
        void WithGarage(bool doesHaveGarage);
        void WithBasement(bool doesHaveBasement);
        void CurrentOccupants(List<Person> personList);
        void AddFloors(int numberOfFloors);
        void CurrentSquareFootage(int squareFootage);

        IBuilding GetBuilding(); 
        #endregion
    }
}
