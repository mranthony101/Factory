﻿using ConsoleApp1.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.BuilderObjects
{
    public class YardBuilder
    {
        private readonly Yard _yard = new Yard();

        public YardBuilder WithGrassType(string grassType)
        {
            _yard.GrassType = grassType;
            return this;
        }

        public YardBuilder WithWidth(int width)
        {
            _yard.Width = width;
            return this;
        }

        public YardBuilder WithLength(int length)
        {
            _yard.Length = length;
            return this;
        }

        public YardBuilder SetYardType(TypeOfYard yardType)
        {
            _yard.YardType = yardType;
            return this;
        }

        public Yard Build() => _yard;
    }
}
