﻿using ConsoleApp1.BuilderObjects;
using ConsoleApp1.Objects;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using ZirMed.Architecture.Security.InternalApi.Proxy;
using ZirMed.Architecture.Security.Model;
using ZirMed.Internal.BillingAPI.Proxy;
using ZirMed.Internal.InternalAPI.Proxy;
using static ConsoleApp1.Objects.Person;

namespace ConsoleApp1
{
    class Program
    {
		static void Main(string[] args)
		{
			var houesBuilder = new HouseBuilder();//Classical
			var director = new Director(houesBuilder);

			var houseObj = director.BuildMinimnalBuilding(3);

			var personBuilder = new PersonBuilder(); //Nested
			var rossPerson = personBuilder.WithAge(31)
				.WithName("Ross Anthony")
				.SetSSN(123)
				.Build();

			var yardBuilder = new YardBuilder();
			var houseYard = yardBuilder.SetYardType(TypeOfYard.Front)
				.WithGrassType("Bermuda")
				.Build();
		}
		
	}
}
