﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Objects
{
    public class Yard
    {
        public string GrassType { get; set; }
        public int Width { get; set; }
        public int Length { get; set; }
        public TypeOfYard YardType { get; set; }
    }

    public enum TypeOfYard
    {
        Front = 1, 
        Back = 2, 
        Side = 3
    }
}
