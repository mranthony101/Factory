﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Objects
{
    public interface ISecuritySystem
    {
        bool IsArmed { get; set; }

        Task ArmSystem();
        Task DisarmSystem();
    }
}
