﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Objects
{
    public interface IBuilding
    {
        #region Properties
        int NumberOfWalls { get; set; }
        int NumberOfDoors { get; set; }
        int NumberOfWindows { get; set; }
        Address Address { get; set; }
        Yard Yard { get; set; }
        ISecuritySystem SecuritySystem { get; set; }
        bool DoesHaveGarage { get; set; }
        bool DoesHaveBasement { get; set; }
        List<Person> PeopleInHouse { get; set; }
        int NumberOfFloors { get; set; }
        int SquareFootage { get; set; }
        #endregion
    }
}
