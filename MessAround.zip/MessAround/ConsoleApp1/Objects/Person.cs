﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Objects
{
    public class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }

        private int _ssn;

        //Nested Builder
        public class PersonBuilder
        {
            private readonly Person _person = new Person();

            public PersonBuilder WithName(string name)
            {
                _person.Name = name;
                return this;
            }

            public PersonBuilder WithAge(int age)
            {
                _person.Age = age;
                return this;
            }

            public PersonBuilder WithGender(string gender)
            {
                _person.Gender = gender;
                return this;
            }

            public PersonBuilder SetSSN(int ssn)
            {
                _person._ssn = ssn;
                return this;
            }

            public Person Build() => _person;
        }
    }


}
