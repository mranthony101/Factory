﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Objects
{
    public class RingSecuritySystem : ISecuritySystem
    {
        public bool IsArmed { get; set; }

        public Task ArmSystem()
        {
            throw new NotImplementedException();
        }

        public Task DisarmSystem()
        {
            throw new NotImplementedException();
        }
    }
}
