﻿using ConsoleApp1.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class House : IBuilding
    {
        #region SimpleProperties
        public int NumberOfWalls { get; set; }
        public int NumberOfDoors { get; set; }
        public int NumberOfWindows { get; set; }
        public Address Address { get; set; }
        #endregion

        #region MoreComplexProperties
        public Yard Yard { get; set; }
        public ISecuritySystem SecuritySystem { get; set; }
        public bool DoesHaveGarage { get; set; }
        public bool DoesHaveBasement { get; set; }
        public List<Person> PeopleInHouse { get; set; }
        public int NumberOfFloors { get; set; }
        public int SquareFootage { get; set; }
        #endregion

        //public House(int numberOfWalls, int numberOfDoors, int numberOfWindows, Address address, Yard yard, ISecuritySystem securitySystem, bool doesHaveGarage, bool doesHaveBasement, List<Person> personList,
        //                int numberOfFloors, int squareFootage)
        //{
        //    NumberOfWalls = numberOfWalls;
        //    NumberOfDoors = numberOfDoors;
        //    NumberOfWindows = numberOfWindows;
        //    Address = address;
        //    Yard = yard;
        //    SecuritySystem = securitySystem;
        //    DoesHaveGarage = doesHaveGarage;
        //    DoesHaveBasement = doesHaveBasement;
        //    PeopleInHouse = personList;
        //    NumberOfFloors = numberOfFloors;
        //    SquareFootage = squareFootage;
        //}
    }
}
