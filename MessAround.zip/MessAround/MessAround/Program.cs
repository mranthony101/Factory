﻿using System;
using System.Data;
using System.IO;

namespace MessAround
{
    public class Program
    {
        static void Main(string[] args)
        {


        }
    }
}
